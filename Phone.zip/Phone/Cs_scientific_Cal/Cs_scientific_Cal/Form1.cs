﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cs_scientific_Cal
{
    public partial class Form1 : Form
    {
        Double results = 0;
        String operation ="";
        bool enter_value = false;
        float i_Celsius,i_Fahrenheit,i_Kelvin;
        char i_Operation;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Width = 244;
            txtDisplay.Width = 198;
                
        }

        private void standardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 244;
            txtDisplay.Width = 198;
                
          

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void scientificToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 480;
            txtDisplay.Width = 437;
        
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            i_Operation = 'C';
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            i_Operation = 'F';
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void temperatureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 840;
            txtDisplay.Width = 437;
        
        }

        private void unitConversionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 840;
            txtDisplay.Width = 437;
        
        }

        private void multiplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 1162;
            txtDisplay.Width = 437;
            txtMultiply.Focus();
        
        }

        private void button_Click(object sender, EventArgs e)
        {
            if ((txtDisplay.Text == "0") || (enter_value))
                txtDisplay.Text = "";
            enter_value = false;
            Button num = (Button)sender;
            if (num.Text == ".")
            {
                if(!txtDisplay.Text.Contains("."))
                    txtDisplay.Text = txtDisplay.Text + num.Text;
            }
            else
                txtDisplay.Text = txtDisplay.Text + num.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text.Length>0)
            {
                txtDisplay.Text = txtDisplay.Text.Remove(txtDisplay.Text.Length - 1, 1);
            }
            if (txtDisplay.Text == "") ;
            {
                txtDisplay.Text = "0";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            
        }

        private void button12_Click(object sender, EventArgs e)
        {
            
        }

        private void button16_Click(object sender, EventArgs e)
        {
           
        }

        private void button20_Click(object sender, EventArgs e)
        {
           
        }

        private void button19_Click(object sender, EventArgs e)
        {
            switch (operation)
            {
                case "+" :
                    txtDisplay.Text = (results + Double.Parse(txtDisplay.Text)).ToString();
                    break;


                case "-":
                    txtDisplay.Text = (results - Double.Parse(txtDisplay.Text)).ToString();
                    break;

                case "*":
                    txtDisplay.Text = (results * Double.Parse(txtDisplay.Text)).ToString();
                    break;

                case "/":
                    txtDisplay.Text = (results / Double.Parse(txtDisplay.Text)).ToString();
                    break;

                default:
                    break;
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "3.14159265";
        }

        private void button22_Click(object sender, EventArgs e)
        {
            double ilog = Double.Parse(txtDisplay.Text);
            ilog = Math.Log10(ilog);
            txtDisplay.Text = System.Convert.ToString(ilog);
        }

        private void button24_Click(object sender, EventArgs e)
        {

            double sq = Double.Parse(txtDisplay.Text);
            sq = Math.Sqrt(sq);
            txtDisplay.Text = System.Convert.ToString(sq);
        }

        private void button28_Click(object sender, EventArgs e)
        {
            Double a;
            a = Convert.ToDouble(txtDisplay.Text) * Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = System.Convert.ToString(a);
        }

        private void button33_Click(object sender, EventArgs e)
        {
             Double a;
            a = Convert.ToDouble(txtDisplay.Text) * Convert.ToDouble(txtDisplay.Text) * Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = System.Convert.ToString(a);
        }

        private void button36_Click(object sender, EventArgs e)
        {
             Double a;
            a = Convert.ToDouble(1.0 / Convert.ToDouble(txtDisplay.Text));
            txtDisplay.Text = System.Convert.ToString(a);
        }

        private void button38_Click(object sender, EventArgs e)
        {
            
            double ilog = Double.Parse(txtDisplay.Text);
            ilog = Math.Log(ilog);
            txtDisplay.Text = System.Convert.ToString(ilog);
        }

        private void button40_Click(object sender, EventArgs e)
        {
         Double a;
            a = Convert.ToDouble(txtDisplay.Text) / Convert.ToDouble(100);
            txtDisplay.Text = System.Convert.ToString(a);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            double qsin = Double.Parse(txtDisplay.Text);
            qsin = Math.Sin(qsin*Math.PI/180);
            txtDisplay.Text = System.Convert.ToString(qsin);

        }

        private void button30_Click(object sender, EventArgs e)
        {
        double qcos = Double.Parse(txtDisplay.Text);
            qcos = Math.Cos(qcos*Math.PI/180);
            txtDisplay.Text = System.Convert.ToString(qcos);

        }

        private void button32_Click(object sender, EventArgs e)
        {
            double qtan = Double.Parse(txtDisplay.Text);
            qtan= Math.Tan(qtan*Math.PI/180);
            txtDisplay.Text = System.Convert.ToString(qtan);

        }

        private void button23_Click(object sender, EventArgs e)
        {
            double qsinh = Double.Parse(txtDisplay.Text);
            qsinh = Math.Sin(qsinh*Math.PI/180);
            txtDisplay.Text = System.Convert.ToString(qsinh);

        }

        private void button25_Click(object sender, EventArgs e)
        {
         double qcosh = Double.Parse(txtDisplay.Text);
            qcosh = Math.Cos(qcosh*Math.PI/180);
            txtDisplay.Text = System.Convert.ToString(qcosh);

        }

        private void button27_Click(object sender, EventArgs e)
        {
             double qtanh = Double.Parse(txtDisplay.Text);
            qtanh= Math.Tan(qtanh*Math.PI/180);
            txtDisplay.Text = System.Convert.ToString(qtanh);
        }

        private void button29_Click(object sender, EventArgs e)
        {
        
        }

        private void button34_Click(object sender, EventArgs e)
        {
        
        }

        private void button39_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtDisplay.Text);
            txtDisplay.Text = System.Convert.ToString(a,18);
        }

        private void button37_Click(object sender, EventArgs e)
        {
         int a = int.Parse(txtDisplay.Text);
            txtDisplay.Text = System.Convert.ToString(a,16);
        }

        private void button35_Click(object sender, EventArgs e)
        {
             int a = int.Parse(txtDisplay.Text);
            txtDisplay.Text = System.Convert.ToString(a,2);
        }

        private void button31_Click(object sender, EventArgs e)
        {
             int a = int.Parse(txtDisplay.Text);
            txtDisplay.Text = System.Convert.ToString(a);
        }

        private void button41_Click(object sender, EventArgs e)
        {
            switch(i_Operation)
            {
                case'C':
                    i_Celsius = float.Parse(txtDisplay.Text);
                    lblConvert.Text = ((((9 * i_Celsius)/5)+32).ToString());
                    break;
                case'F':
                    i_Fahrenheit = float.Parse(txtDisplay.Text);
                    lblConvert.Text = ((((i_Fahrenheit - 32)*5)/9).ToString());
                    break;
                case 'K':
                    i_Kelvin = float.Parse(txtDisplay.Text);
                    lblConvert.Text = (((((9 * i_Kelvin)/5)+32) +273.15).ToString());
                    break;
                default:
                    break;


            }
        }

        private void button42_Click(object sender, EventArgs e)
        {
            textConvert.Clear();
            lblConvert.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton6.Checked = false;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
           
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            i_Operation = 'K';
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {
        
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void FstMultiply_SelectedIndexChanged(object sender, EventArgs e)
        {
        
        }

        private void button43_Click(object sender, EventArgs e)
        {
            int a;
            a = Convert.ToInt32(txtMultiply.Text);
            for(int i = 1;i<13; i++)
            {
                FstMultiply.Items.Add(i + "x" + a + "-" + a * i);
            }
        }

        private void btnResetM_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
            FstMultiply.Items.Clear();
        }

        private void Arithmetic_operator(object sender, EventArgs e)
        {

            

        }

        private void Operator(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            operation = num.Text;
            results = Double.Parse(txtDisplay.Text);
            txtDisplay.Text = "";

        }
        }
        }
   
    

